# MINH TEMPLATES FACTORY — F17: Thu chi doanh nghiệp và dòng tiền startup

Bộ giải pháp thương mại chuẩn hóa 5 tầng:
- **Free Demo** (0 VND): Trải nghiệm dữ liệu mẫu thực tế.
- **Free Clean** (0 VND): Cấu trúc bảng và công thức sạch sẽ, sẵn sàng nhập liệu.
- **Basic** (49.000 VND): 3 KPI Cards, 1 biểu đồ, menu điều hướng.
- **Pro** (119.000 VND - Bestseller): Đầy đủ 5-6 KPI Cards, bảo vệ ô công thức, phân tích đa chiều.
- **Business** (499.000 VND): Nhật ký kiểm toán `AUDIT_LOG`, triggers tự động `onEdit`.

### Hướng Dẫn Cài Đặt Nhanh
1. Mở một Google Spreadsheet trắng.
2. Vào **Tiện ích mở rộng** (Extensions) > **Apps Script**.
3. Dán nội dung file `setup.gs` (hoặc gói mong muốn) vào và bấm **Lưu** (Ctrl + S).
4. Tải lại Google Sheets (F5) và kích hoạt từ menu **MINH TEMPLATES**.